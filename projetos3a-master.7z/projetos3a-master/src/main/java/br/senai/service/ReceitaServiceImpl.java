package br.senai.service;

import br.senai.model.Receita;
import br.senai.repository.ReceitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceitaServiceImpl implements ReceitaService{
    @Autowired
    ReceitaRepository receitaRepository;

    @Override
    public List<Receita> findAll(){
        return receitaRepository.findAll();
    }

    @Override
    public Receita findById(Long id){
        Receita findReceita = receitaRepository.findById(id).get();
        return findReceita != null ? findReceita : new Receita();
    }

    @Override
    public Receita save(Receita receita){
        try{
            return receitaRepository.save(receita);
        }catch (Exception e){
            throw e;
        }
    }

    @Override
    public void deleteById(Long id) {
        try{
            receitaRepository.deleteById(id);
        }catch (Exception e){
            throw e;
        }
    }
}
