package br.senai.service;

import br.senai.model.Receita;

import java.util.List;

public interface ReceitaService {
    public List<Receita> findAll();
    public Receita findById(Long id);
    public Receita save(Receita receita);
    public void deleteById(Long id);
}
