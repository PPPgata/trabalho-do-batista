package br.senai.controller;

import br.senai.model.Receita;
import br.senai.service.FuncionarioService;
import br.senai.service.FuncionarioServiceImpl;
import br.senai.service.ReceitaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReceitaController {
    @Autowired
    ReceitaServiceImpl receitaService;

    @Autowired
    FuncionarioServiceImpl funcionarioService;

    @GetMapping("/receitas/list")
    public String findAll(Model model){
        model.addAttribute("receita", receitaService.findAll());
        return "receitas/list";
    }

    @GetMapping("/receitas/add")
    public String add(Model model){
        model.addAttribute("receita", new Receita());
        model.addAttribute("funcionarios", funcionarioService.findAll());
        return "receitas/add";
    }

    @GetMapping("/receitas/edit/{id}")
    public String edit(@PathVariable Long id, Model model){
        model.addAttribute("receita", receitaService.findById(id));
        model.addAttribute("funcionarios", funcionarioService.findAll());
        return "receitas/edit";
    }

    @PostMapping("/receitas/save")
    public String save(Receita receita, Model model){
        try{
            Receita saveReceita = receitaService.save(receita);
            model.addAttribute("receita", saveReceita);
            model.addAttribute("funcionarios", funcionarioService.findAll());
            model.addAttribute("isSaved",true);
            model.addAttribute("isError",false);
        }catch (Exception e){
            model.addAttribute("receita", receita);
            model.addAttribute("funcionarios", funcionarioService.findAll());
            model.addAttribute("isSaved",false);
            model.addAttribute("isError",true);
        }
        return "receitas/add";
    }

    @GetMapping("/receita/delete/{id}")
    public String delete(@PathVariable long id){
        try{
            receitaService.deleteById(id);
        }catch (Exception e){
            System.out.println("Erro ao deletar. "+ e.getMessage());
        }

        return "redirect:/receitas/list";
    }



}
