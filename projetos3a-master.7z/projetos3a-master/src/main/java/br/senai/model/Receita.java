package br.senai.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Entity(name = "receita")
public class Receita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size (max = 100)
    @NotNull
    private String Nome;

    @Size (max = 999)
    @NotNull
    private String tutorial;

    @Size (max = 999)
    @NotNull
    private String ingredientes;

    @NotNull
    private double orcamento;

    @ManyToMany
    @JoinTable(
            name = "projeto_funcionario",
            joinColumns = @JoinColumn(name = "projeto_id",
                    referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(name = "funcionario_id",
                    referencedColumnName = "id"
            )
    )

    private List<Funcionario> funcionarios;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public String getTutorial() {
        return tutorial;
    }

    public void setTutorial(String tutorial) {
        this.tutorial = tutorial;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public double getOrcamento() {
        return orcamento;
    }

    public void setOrcamento(double orcamento) {
        this.orcamento = orcamento;
    }

    @Override
    public String toString() {
        return "Receita{" +
                "id=" + id +
                ", Nome='" + Nome + '\'' +
                ", tutorial='" + tutorial + '\'' +
                ", ingredientes='" + ingredientes + '\'' +
                ", orcamento=" + orcamento;
    }
}
